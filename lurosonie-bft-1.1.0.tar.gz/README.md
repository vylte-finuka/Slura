# Lurosonie-BFT 1.1.0

Nœud EVM portable de la chaîne **Slura** (Vyft).

## Installation (Homebrew)

```bash
brew install --formula https://raw.githubusercontent.com/\( {REPO}/master/ \){FORMULA_PATH}
```

## Lancement

```bash
lurosonie-bft --help
```
